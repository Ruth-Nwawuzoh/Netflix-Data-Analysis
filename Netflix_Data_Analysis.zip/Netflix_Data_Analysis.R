# Load the necessary libraries
library(ggplot2)

myDataPath <- "C:\\Users\\ruthn\\OneDrive\\Documents\\R2\\NXU\\BAN6420\\MODULE 4\\Netflix_shows_movies_cleaned.csv"

data <- read.csv(myDataPath)

# Visualization: Most Watched Genres
ggplot(data, aes(x = rating)) +
  geom_bar(fill = "blue") +
  theme_minimal() +
  ggtitle("Ratings Distribution") +
  xlab("Rating") +
  ylab("Frequency") 